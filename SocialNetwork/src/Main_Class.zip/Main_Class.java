/* Main Class
 * @author	Katyayani Singh (2015046)
 * @author	Sagar Khurana (2015167)
 */


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class Main_Class {
	
	public static void main(String args[]) throws IOException, FileNotFoundException, UnsupportedEncodingException{
		myNetwork.Read_File();
		myNetwork.Welcome();
	}
	
}
